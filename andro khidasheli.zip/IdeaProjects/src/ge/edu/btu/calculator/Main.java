package ge.edu.btu.calculator;

public class Main { public static void main(String[] args) {

    int x = 20;
    int y = 10;
    System.out.println(x + " + " + y + " = " +
            (x + y));
    System.out.println(x + " / " + y + " = " +
            (x / y));
}
}


