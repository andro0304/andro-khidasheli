package ge.edu.btu.calculator.service;

public interface CalculatorService {
}
